package com.mindgate.main.repository;

import com.mindgate.main.domain.Login;

public interface LoginRepository {
	Login login(Login login);
}
