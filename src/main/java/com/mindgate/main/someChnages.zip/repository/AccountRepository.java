package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.Account;


public interface AccountRepository {
    
    List<Account> getAllNewAccounts();
    List<Account> getAllNewAccountsByCusstomerId(int customerId);
    boolean approveAccount(int accountNumber);
    boolean rejectAccount(int accountNumber);
    Account getAccountByAccountNumber(int accountNumber);

}
