package com.mindgate.main.service;

import com.mindgate.main.domain.Login;

public interface LoginService {
    public Login login(Login login);
}
