package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.Account;

public interface AccountService {
        
    List<Account> getAllNewAccounts();
    List<Account> getAllNewAccountsByCusstomerId(int customerId);
    boolean approveAccount(int accountNumber);
    boolean rejectAccount(int accountNumber);
    Account getAccountByAccountNumber(int accountNumber);
    

}

